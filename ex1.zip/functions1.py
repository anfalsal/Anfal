# this function calculates the factorial of 10
import math


def factorial_10():
    return math.factorial(10)
# print(factorial_10()
# this function Calculates the area of  circle
# r = float(input('enter the radiuse: '))


def circle_area(r):
    area = math.pi * r * r
    return area
# print(circle_area(r))
# this function Gets an angle in degrees and returns it in radians
# n = float(input('enter the angle: '))


def degrees_to_radians(n):
    rad = n * (math.pi/180)
    return rad
# print(degrees_to_radians(n))
# this function Calculates the hypotenuse of the triangle by the pythagorean theorm
# a = int(input('what is a? '))
# b = int(input('what is b? '))


def pythagorean_theorem(a, b):
    if a <= 0:
        return 'not valid'
    if b <= 0:
        return 'not valid'
    c = b ** 2 + a ** 2
    math.sqrt(c)
    return math.sqrt(c)