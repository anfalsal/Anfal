# this function Converts degrees from Fahrenheit to Celsius and vice versa
# F = fahrenheit , C= celsius
# equation: F = (9/5 *C)+32
# a = int(input('what is the temp? '))
# b = str(input('which unit? '))


def convert_degree(a, b):
    if (type(a) == int or type(a) == float) and a >= -273 and b == "F":
        return (a*9/5)+32
    if (type(a) == int or type(a) == float) and a >= -459 and b == "C":
        return (a-32)*5/9
    elif b != 'C' and b != "F":
        return None


# print(convert_degree(100 , 'F') )
# this function takes a string as the parameter and extract the temperature from it, convert it to a different unit
# and returns the original and the converted temperature.
# my_sent = "Convert to celsius 451"


def natural_language_convert_degree(my_sent):
    list1 = my_sent.split()
    if not list1[-1].isnumeric():
        return None
    numb = float(list1[-1])
    if list1[2] == 'celsius':
        return numb, convert_degree(numb, 'C')
    if list1[2] == 'fahrenheit':
        return numb, convert_degree(numb, 'F')
    else:
        return None
