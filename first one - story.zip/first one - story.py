name = input("enter your name : ")
age = input("enter your age: ")
color = input("enter your favourite color: ")
job = input("enter your job:  ")

print("my name is " + name)
print("my age is " + age)
print("my favourite color is " + color)
print("my job is " + job)