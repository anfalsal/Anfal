import copy
import math


# 1. perimeter : This question calculates the distance between two points and
# then adds the sides to calculate the perimeter
def perimeter(x, y):
    first = len(x)
    result = []
    for i in range(first):
        x2 = x[i-1]
        x1 = x[i]
        y2 = y[i-1]
        y1 =y[i]
        d = math.sqrt(((x2 -x1)**2) +(y2 -y1)**2)
        result.append(d)
        d_sum = 0
        for r in result:
            d_sum += r
    return d_sum

#print(perimeter([0, 1, 0], [0, 0, 1]))



# 2. Empirical distribution: This question performs the empirical distribution of values within a list
def empirical_distribution(lst, vals):
    a = 0
    count = []
    for i in vals:
        a = 0
        for b in lst:
            if i == b:
                a += 1
        count += [a / len(lst)]
    return count

#print(empirical_distribution([7,2,3,2,3],[-1,2,7]))

# 3. Luah hakefel: This question calculates the multiplication table for each number before n
def mult_table(n):
    lst_table = []
    for i in range(1, n + 1):
        lst_table2 = []
        for b in range(1, n + 1):
            lst_table2 += [i * b]
        lst_table += [lst_table2]
    return lst_table


# print(mult_table(5))


# 4. update means : This question updates the rate of the list of numbers that we add every time
def update_means(lst, n=0, cur_means=(0, 1, 1)):
    a = cur_means[0] * n
    b = (cur_means[1]) ** n
    c = n / cur_means[-1]
    check_num = 1
    update_harm_mean = 0
    for i in lst:
        check_num *= i
    if check_num == 0:
        update_harm_mean = None
    else:
        for i in lst:
            c += 1/i
            if update_harm_mean != None:
                update_harm_mean = (n + len(lst)) / c
    for j in lst:
        a += j
        b *= j
    update_means = a / (n + len(lst))
    if b < 0:
        update_geo_mean = None
    else:
        update_geo_mean = b ** (1 / (n + len(lst)))
    return  update_means , update_geo_mean , update_harm_mean

# 5. divisors : This question accepts a positive integer "n"
# and prints a list representing all the divisors of all numbers from 1 to "n".
def divisors_upto(n):
    empty_list = []
    for i in range(1, n+1):
        list_2 = []
        for b in range(1, n+1):
            if i % b == 0:
                list_2.append(b)
        empty_list.append(list_2)
    return  empty_list
#print(divisors_upto(2))



# 6. permutations : This question gives you all the possibilities of switching items within a list
def permutations_upto(n):
    final_lst = [[[1]]]
    for i in range(1, n):
        empty_lst = []
        for lst in final_lst[i-1]:
            for k in range(len(lst)+1):
                new_lst = copy.deepcopy(lst)
                new_lst.insert( k , i+1)
                empty_lst.append(new_lst)
        final_lst.append(empty_lst)
    return final_lst

