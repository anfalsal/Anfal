# Q1: Sum Of Digit Of A Number Using Recursion
def sum_digits(n):
    if type(n) != int:
        return "This number is not an integer"
    if n < 0:
        return "This number is not an integer"
    else:
        if n == 0:
          return 0

    return (n % 10 + sum_digits(int(n/10)))



# Q2: Calculate the Power using Recursion
def power(a,b):
    if b == 0:
        return 1
    if b == 1:
        return a
    else:
        return (a * power(a,b-1))



# Q3: Reverse a String using Recursion
def reverse(string):
    if len(string) == 0:
        return string
    else:
        return reverse(string[1:]) + string[0]

# Q4:
class Animal:
    def __init__(self, name , health = 50):
        self.name = name
        self.health = health
    def walk(self):
        self.health -= 1
        return self
    def run(self):
        self.health -= 5
        return self

    def displayHealth(self):

        sentence = 'The health of {} is: {}'
        return sentence.format(self.name , self.health)


class Dog(Animal):
    def __init__(self, name, health = 150 ):
        self.name = name
        self.health = health
    def pet(self):
        self.health += 5
        return self
class Raven(Animal):
        def __init__(self, name, health = 170 ):
            self.name = name
            self.health = health
        def fly(self):
            self.health -= 10
            return self
        def display(self):
            return self.displayHealth() + ". I am a Raven. SQUACK!"

















