# Q1
#this function makes a list of the common string
list = ['carrot', 'cake', 'apple', 'pie', 'mushroom', 'pie', 'potato', 'pie', 'cheese', 'cake', 'butter', 'cake', 'old','cake', 'milk', 'pie']
string = ['ke']
def in_str(list,string):
    list22 = []
    for i in list:
        for b in string:
            if b in i:
                list22 += [i]
    return list22


# Q2
#this function makes a list of the common string and the word before it
def minus_in_str(list, string):
    list222 = []
    if string in list[0]:
        list222 += [list[0]]
    for i in range(1,len(list)):
        for b in string:
            if b in list[i]:
                list222 += [list[i-1]+ ' ' + list[i]]
    return list222


# Q3
#this function makes a list of the common string and the word after it
def plus_in_str(list , string):
    new_list = []
    for i in range(0,len(list)-1):
        for b in string:
            if b in list[i]:
                new_list += [list[i] + ' ' + list[i+1]]
            if b in list[-1]:
                new_list += list[-1]
    return new_list

# Q4
# This function checks if the number we received is correct, if so it will print correctly, if not it will print incorrectly.
# "An even number is an elaborate number" if it is odd the function will print that it is odd
# 4-A
def perfect_number(a):
    b = 0
    while a >0:
        if a%2 != 0:
            return 'The number is odd'
        for i in range(1,a):
            if a%i == 0:
                b += i
        if a == b:
            return a
        else:
            return 'The number is not perfect'

#print(perfect_number(7))
# 4-B
#this function takes a positive number, and finds athh the perfect number befre it
def all_perfect_numbers(a):
    list4 = []
    while a >0:
        for i in range(1,a+1):
            if perfect_number(i) == i:
                list4 += [i]
        return list4
#print(all_perfect_numbers(30))

# Q5
# this function checks if the input is an interger, if it is, it will check its common factors and sum them up
def find_integers(x):
    list5 = []
    if type(x) != int:
        return 'This number is not an integer'
    while type(x) == int:
        for i in range(1,x):
            if x % i == 0:
                list5 += [i]
        return sum(list5)
# Q6
# this function takes a string, and find out how many characters are there:
def number_characters(str):
    str = str.replace(" ", "")
    length = len(str)
    return length

#print(number_characters("שלום כיתה א׳"))



