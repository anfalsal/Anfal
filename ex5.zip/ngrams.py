# Q1 : calculation of frequencies
def compute_ngram_frequency(text,n):
    dict = {}  # Create dictionary
    do_not_count = [" ", "\n", ".", ",","'","?"]
    txt = text.lower()
    for character_idx in range(len(txt) - (n-1)):
        this_ngram = txt[character_idx:character_idx + n]

        ngram_ok = True
        for item in do_not_count:  # Checking if any of the forbidden things is in the ngram
            if item in this_ngram:  # FOUND ONE!
                ngram_ok = False  # ngram not ok

        if ngram_ok is True:
            if this_ngram not in dict:
                dict[this_ngram] = 1
            else:
                dict[this_ngram] += 1

    dict = {key: value / sum(list(dict.values())) for key, value in dict.items()}
    return dict


# Q2: translate a dict to string
def ngram_dict_to_string(dict):
    dict_str = ""
    for key, value in dict.items():
        dict_str += str(key) + ":" + str(value) + " "
    return dict_str



# Q3: translation of a string to dict
def string_to_ngram_dict(my_str):
    new_dict = {}
    str_split = my_str.split(' ')
    str_split = str_split[:len(str_split)-1]
    for i in str_split:
        key_val = i.split(':')
        new_dict[key_val[0]] = float(key_val[1])
    return new_dict


# Q4: saving a dict after translate it to string in a file
def write_ngram_dict(dict, filename):
    text_file = open(filename)
    # write string to file
    text_file.write(ngram_dict_to_string(dict))
    # close the file
    text_file.close()


# Q5: loading a compiled dict
def read_ngram_dict(filename):
    with open(filename) as filename:
        string_txt = filename.read()
    return string_to_ngram_dict(string_txt)









