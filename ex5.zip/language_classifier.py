import ngrams
import os
from ngrams import compute_ngram_frequency, write_ngram_dict, ngram_dict_to_string, string_to_ngram_dict, read_ngram_dict
# Q6: Building a dictionary for the language
def build_language_model(language_filename, n, dict_filename=''):
   if os.path.isfile(language_filename):
      f = open(language_filename)
      txt = f.read().lower()
      try:
          'a' or 'e' or 'u' or 'o' or 'i'
      except:
          print(None)
      probability_of_n = compute_ngram_frequency(txt, n)
      if dict_filename != '':
          not_empty = write_ngram_dict(probability_of_n, dict_filename)
          return not_empty
      else:
          return probability_of_n
   elif not os.path.isfile(language_filename):
       return None

# Q7: Distance between two dictionaries
def compute_ngram_distance(dict1, dict2):
    count = 0
    for key1 in dict1:
        if key1 in dict2:
            count += (dict1[key1]-dict2[key1])**2
        else:
            count += (dict1[key1])**2
    return count


# Q8: Reducing dictionary size
def reduce_ngram(dict , n):
    dict_new = {}
    if len(list(dict.keys())[0]) < n :
        return False and print("Error! Current ngram size smaller than" [n])

    for key in dict.keys():
        new_key = key[:n]
        if new_key in dict_new:
            dict_new[new_key] += dict[key]
        else:
            dict_new[new_key] = dict[key]
    return dict_new

# Q9: Text language prediction
def classify_language(text_to_classify, list_of_dict_files):
    length, dis = [], []
    dict_file_1 = ngrams.read_ngram_dict(list_of_dict_files[0])
    for key in dict_file_1: length.append(len(key))
    dict_file_2 = ngrams.read_ngram_dict(list_of_dict_files[1])
    for key in dict_file_2: length.append(len(key))
    dict_file_3 = ngrams.read_ngram_dict(list_of_dict_files[2])
    for key in dict_file_3: length.append(len(key))
    dict_file_4 = ngrams.read_ngram_dict(list_of_dict_files[3])
    for key in dict_file_4: length.append(len(key))
    order_n = min(length)
    new_dict = build_language_model(text_to_classify, order_n)
    if length[0] > order_n: dict_file_1 = reduce_ngram(dict_file_1, order_n)
    dis.insert(0, compute_ngram_distance(new_dict, dict_file_1))
    if length[1] > order_n: dict_file_2 = reduce_ngram(dict_file_2, order_n)
    dis.insert(1, compute_ngram_distance(new_dict, dict_file_2))
    if length[2] > order_n: dict_file_3 = reduce_ngram(dict_file_3, order_n)
    dis.insert(2, compute_ngram_distance(new_dict, dict_file_3))
    if length[4] > order_n: dict_file_4 = reduce_ngram(dict_file_4, order_n)
    dis.insert(3, compute_ngram_distance(new_dict, dict_file_4))
    index_min = dis.index(min(dis))
    return index_min







































