# Solution: Implement sudoku solving
# 1. Check if board is complete
def sudoku_iscomplete(board):
    for i in range(9):    # horizontal
        for j in range(9):     # vertical
            if board[i][j] == 0:
                return False

    return True


# 2. Return the 3*3 square covering x,y
def sudoku_square3x3(board, x, y):
    h = x // 3 * 3  # horizontal
    v = y // 3 * 3  # vertical
    square = []
    for i in range(h, h + 3):
        square.append([board[i][v], board[i][v + 1], board[i][v + 2]])
    return square



# 3. Get available options of a position
def sudoku_options(board, x, y, diag=False):
    if board[x][y] > 0:
        s, board[x][y] = board[x][y], 0
        options = sudoku_options(board, x, y, diag)
        board[x][y] = s
        return options
    options = set(range(1, 10)).difference(board[x])
    options = options.difference({board[i][y] for i in range(9)})
    options = options.difference({j for i in sudoku_square3x3(board, x, y) for j in i })
    if diag:
        if x == y:
            options = options.difference({board[i][i] for i in range(9)})
        if x == 8-y:
            options = options.difference({board[i][8-i] for i in range(9)})
    return options


# 4. find all positions which have one option to fill
def find_all_unique(board, diag=False):
    lst = []
    for x in range(len(board)):
        for y in range(len(board[x])):
            if len(sudoku_options(board, x, y, diag)) == 1 and board[x][y] == 0:
                val = list(sudoku_options(board, x, y))[0]
                lst += [(x, y, val)]
    return lst



# 5. Check if board is valid
def sudoku_isvalid(board, diag=False):
    for i in range(len(board)):
        for j in range(len(board)):
            if board[i][j] == 0:
                return False

    for row in board:
        if not all(1 <= val <= 9 for val in row):
            return False

    for col in range(len(board)):
        if not all(1 <= board[row][col] <= 9 for row in range(len(board))):
            return False
        return True

    for x in range(3):
        for y in range(3):
            if not sudoku_square3x3(board, x, y):
                return False

# Helper: Find squares with no option to fill
# def find_all_conflicts_consider_current_square(board, diag=False):


# 6. Find squares with no option to fill
def find_all_conflicts(board, diag=False):
    lst_conf = []
    for x in range(len(board)):
        for y in range(len(board)):
            if len(sudoku_options(board,x,y,diag)) == 0:
                lst_conf += [(x,y)]
    return lst_conf

# 7. Add square:
def add_square(board, i, j, val, diag=False):
    if val in sudoku_options(board , i , j ,diag):
        board[i][j] = val
        return True
    else:
        print('Error! Value is in conflict with current board')
        return False



# 8. Iteratively fill the board with unique options
def fill_board(board, diag=False):
    counter = 1
    while counter != 0:
        for i in range(9):
            for j in range(9):
                option = sudoku_options(board, i, j, diag)
                v = board[i][j]
                if v ==0:
                    if len(sudoku_options(board, i, j, diag)) == 1:
                        counter += 1
                else:
                    if len(option) == 0:
                        print('Error! current sudoku leads to inconsistencies. Must delete values ')
                        return False
        if sudoku_iscomplete(board):
            print('Success! sudoku solved')
        else:
            print('Sudoku partially solved')
            return True






# Helper: check conflicts only for empty squares
#def find_all_conflicts_empty_squares(board, diag=False):



# Helper: Fill unique positions. These must be re-checked one by one, not all (then there can be new conflicts!)
#def fill_all_unique(board, diag=False):
